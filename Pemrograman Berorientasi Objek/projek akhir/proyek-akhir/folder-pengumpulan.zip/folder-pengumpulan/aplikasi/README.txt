jika file .exe tdk bisa jalankan file .jar
Untuk menjalankan aplikasi silahkan pastikan JRE sudah terinstall
- java -version
- buka terminal pada folder aplikasi
- java -jar pengingat-peregangan.jar


