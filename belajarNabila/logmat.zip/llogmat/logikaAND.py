def gerbang_and(input1, input2):
    return input1 and input2

# Contoh penggunaan gerbang AND
input_1 = input("masukan p: ")
input_2 = input("masukan q: ")
hasil_and = gerbang_and(input_1, input_2)

print(f"Hasil AND dari {input_1} dan {input_2} adalah {hasil_and}")
