import logikaAND as opr

def pilihan():
    print ('''     PILIH  GERBANG LOGIKA     
          1. gerbang AND.
          2. gerbang OR
          3. gerbang NAND
          4. gerbang NOR
          5. gerbang XOR    ''')
    opsi = input("pilih opsi: ")
    return opsi

pilih = pilihan()
if pilih == 1:
    print(opr.logikaAND)
